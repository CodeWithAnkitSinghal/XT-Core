class Account{
    constructor(num, balance){
        this.num = num;
        this.balance = balance;
    }
}

module.exports = Account;